This directory examples of predictive models for the See.4C video forecasting contest.

ALL INFORMATION, SOFTWARE, DOCUMENTATION, AND DATA ARE PROVIDED "AS-IS". The SEE.4C CONSORTIUM, AND/OR OTHER ORGANIZERS OR CODE AUTHORS DISCLAIM ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR ANY PARTICULAR PURPOSE, AND THE WARRANTY OF NON-INFRIGEMENT OF ANY THIRD PARTY'S INTELLECTUAL PROPERTY RIGHTS. IN NO EVENT SHALL AUTHORS AND ORGANIZERS BE LIABLE FOR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF SOFTWARE, DOCUMENTS, MATERIALS, PUBLICATIONS, OR INFORMATION MADE AVAILABLE FOR THE CHALLENGE.

You must copy predictSpatioTemporal_xxx.py to ../predictSpatioTemporal.py

1) predictSpatioTemporal_persistence.py: The most basic (and fast) model. it just predicts that the next farm is identical to the last one. Unfortunately this “stupid” model is hard to beat!
2) predictSpatioTemporal_linear.py: A slightly fancier auto-regressive linear model.
3) predictSpatioTemporal_prednet.py: A deep learning method.
RIGHT NOW THIS MODEL DOES NOT GET TRAINED (because training is very slow unless you have a GPU). To make it train, set DEBUG_MODE = 0.

==========================

PREDNET TIPS:

In order to run this code, please consider the following:

1) The file predictSpatioTemporal.py has 1 control variable:
   
   - DEBUG_MODE  -> set it to 0 to train the model; 
                 -> set it to 1 to load a pretrained model. In this case, you must have inside 'cache' directory 3 files: 
                    num_seq_valid.npy, prednet_kitti_weights.hdf5, and prednet_kitti_model.json 

   # ps.: the code will try to copy a configuration file to ~/.keras directory. If you plan to run the code in your
   # local compyter, remember to make a backup first. 


2) Below, some hyper-parameters of the model are commented:


    hyper_param = { 'cache_dir': cache_dir,
                    'version': 'faces_32_1',
                    'model_name': 'prednet_kitti',
                    'S_HELD': 10, # number of frames used to train the model
                    'S_PRED': 1, # number of predicted frames (the current implementation rearrange all the clips to 10+1 frames)
                    'TRAIN_SAMPLES': 0.95, # considering all the data you have inside train directory, 0.95 will be used to train and 0.5 as validation (during training)
                    'test_batch_size': 10, 
                    'train_batch_size': 4,
                    'nb_epoch': 150,
                    'samples_per_epoch': 500,
                    'nt': 10, # the real number of frames used to train (cannot be higher than S_HELD)
                    'input_shape' : (1, 32, 32),
                    'stack_size' : (48, 96, 192),
                    'A_filt_sizes' : (3, 3, 3),
                    'Ahat_filt_sizes' : (3, 3, 3, 3),
                    'R_filt_sizes' : (3, 3, 3, 3),
                    'layer_loss_weights' : [1., 0., 0., 0.],
                    'loss': 'mean_absolute_error',
                    'optimizer': 'adam',
                    'start_lr': 0.001,
                    'end_lr': 0.0001,
                    }



Also about the hyper-parameters, some suggestions from Bill Lotter, one of the authors of the original model:

1. "stack sizes" controlling the number of filters per layer. I typically try to make this grow at a factor of 1.5 or 2 per layer (i.e. 16 filters in first layer, 32 or 24 in second, etc.), with the max number of filters getting to around 200 or so, depending on the resolution of the images and memory/computational time constraints.
2. The number of layers. This is implicitly controlled by the length of "stack sizes", i.e. stack_sizes = [1, 32, 64, 128] would consist of 4 layers.  4 or 5 layers is what I would try.
3. Filter sizes (as in "A_filt_sizes", "R_filt_sizes", "Ahat_filt_sizes"). These control the size of the filters in the layers. 3x3 filters are the norm these days and that's also what I've had the most success with, but trying a filter size of 5 at the lowest layer is also reasonable







