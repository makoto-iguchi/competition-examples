
import os
import numpy as np

from keras.models import Model, model_from_json
from keras.layers import Input, Dense, Flatten
from keras.layers import TimeDistributed
from keras.callbacks import LearningRateScheduler, ModelCheckpoint

from prednet import PredNet
from prednet_utils import SequenceGeneratorChalearn
from data_io import vprint
import h5py
from data_manager import DataManager

import sys
import glob


class prednet_baseline():
    def __init__(self, hyper_param, path="", verbose=False):
        for key in hyper_param:
            setattr(self, key, hyper_param[key])
        self.model_dir = path
        # We could set other hyper_parameters from outside, for now they are fixed
        self.verbose=verbose
#        vprint(self.verbose, "--> Version = " + self.version)
#        vprint(self.verbose, "--> Cache dir = " + self.cache_dir)
#        vprint(self.verbose, "--> Model dir = " + self.model_dir)
#        vprint(self.verbose, "--> Hyper_parameters : ")
#        vprint(self.verbose, hyper_param)
        self.WEIGHTS_DIR = self.cache_dir
        self.DATA_DIR = self.cache_dir
        #self.nt = self.S_HELD + self.S_PRED
        self.weights_file = os.path.join(path, self.WEIGHTS_DIR, self.model_name + '_weights.hdf5')
        self.json_file = os.path.join(self.WEIGHTS_DIR, self.model_name + '_model.json')
#        print(self.json_file)

##-------------------------------------------


    # get the list of directories inside 'input/train' and number of files
    def get_dir_list(self, data_dir):
       d = os.listdir(os.path.join(data_dir,'train'))
       d_list = []
       print "checking number of files within train directory"
       # check for valid directories (starting with 'Xm')
       for i in range(0,len(d)):
          aux = d[i]
          if aux[0:2] == 'Xm':
             d_list.append(aux)
          else:
             print "%s -> not valid directory" %aux

       # get the number of files within each directory
       for i in range(0,len(d_list)):
          f_list = glob.glob(os.path.join(data_dir,"train",d_list[i])+'/*.h5')
          d_list.append(len(f_list))

       print d_list
       return d_list
    #-----------------



    #-------------------------------------------
    # this function rearrange the hackathon data to the one used by the prednet (first, for train data)
    def generate_train_data(self, data_dir):

       # determining the number of available train samples
       train_dir = self.get_dir_list(data_dir)
       n_dir = len(train_dir)/2
       total_files = 0
       for i in range(0,n_dir):
          total_files = total_files + train_dir[n_dir+i]

       # computing the number of samples used for training
       num_train = int(self.TRAIN_SAMPLES*total_files)

       # for each clip with 125 frames, we will generate 11 clips with 10+1 frames, withtout overlap in frames.
       # (the last 4 frames of each clip are ignored). Thus, at the prediction stage, 
       # from 10 frames we will predict just the next 1, shift the data (using the predicted frame as input), and predict the next 1, and so on.
       new_data = np.zeros((num_train*11,10+1,1,32,32))
       print "Generating train data..."

       # loading train samples used to train (from different directories)
       sample_counter = -1
       cont = -1
       # for each directory
       for i in range(0,n_dir):
          final_data_dir = os.path.join(data_dir, 'train',train_dir[i])
          # for each file inside the directory
          for j in range(1,train_dir[n_dir+i]+1):
             # if trainning sample (not validation)
             sample_counter = sample_counter+1
             print sample_counter+1
             filename = 'X' + str(j) + '.h5'
             f = h5py.File(os.path.join(final_data_dir, filename), 'r')
             frames = f['X']['value']['X']['value'][:]
      
             if sample_counter < num_train:
                delta = 0
                # generating the 11 clips
                for s in range(0,11):
                   cont = cont+1
                   for k in range(0,10+1):
                      new_data[cont,k,0,0:32,0:32] = frames[k+delta,0:32,0:32]
                   delta = delta + 11
             else:
                if sample_counter == num_train:
                   # save the rearranged data (train set)
                   if not os.path.exists(self.DATA_DIR):
                      os.makedirs(self.DATA_DIR)
                   np.save(os.path.join(self.DATA_DIR, self.version + '_train.npy'), new_data)

                   print "generating validation data"
                   new_data = np.zeros(((total_files-num_train)*11,10+1,1,32,32))
                   cont = -1
                # generating validation data 
                delta = 0
                # generating the 11 clips
                for s in range(0,11):
                   cont = cont+1
                   for k in range(0,10+1):
                      new_data[cont,k,0,0:32,0:32] = frames[k+delta,0:32,0:32]
                   delta = delta + 11

       # save the rearranged data (validation set)
       np.save(os.path.join(self.DATA_DIR, self.version + '_valid.npy'), new_data)
       np.save(os.path.join(self.DATA_DIR, 'num_seq_valid.npy'), total_files-num_train)
    #--------------




    #--------------------------
    # this function rearrange the input data (from adapt folder) to prednet specifications (and also to the problem)
    def generate_test_file(self, data_path,clip_id,id_aux):
     
       # aux data file 
       data = np.zeros((1,10+1,1,32,32))
       NEW_DATA_DIR = os.path.join(data_path, 'adapt/')

       # if it is the first clip (only one with 101 frames in the dataset)
       if id_aux==0:
          f = h5py.File(os.path.join(NEW_DATA_DIR,'X' + str(clip_id) + '.h5'), 'r')
          frames = f['X']['value']['X']['value'][:]
          # consider just the last 10 frames
          for j in range(91,101):
             data[0,j-91,0,0:32,0:32] = frames[j,0:32,0:32]

       # if it is the '8 length' clip
       if id_aux==1 or id_aux==2:
          data = np.load(os.path.join(self.DATA_DIR, self.version + '_test.npy'), 'r+')
          f = h5py.File(os.path.join(NEW_DATA_DIR,'X' + str(clip_id) + '.h5'), 'r')
          frames = f['X']['value']['X']['value'][:]
          # shift the data first (just two last frames of previous given sequence)
          for j in range(9,11):
             data[0,j-9,0,0:32,0:32] = data[0,j,0,0:32,0:32]
          # append the new data
          for j in range(0,8):
             data[0,2+j,0,0:32,0:32] = frames[j,0:32,0:32]

       # if it is the '109 length' clip
       if id_aux==3:
          data = np.zeros((1,10+1,1,32,32))
          f = h5py.File(os.path.join(NEW_DATA_DIR,'X' + str(clip_id) + '.h5'), 'r')
          frames = f['X']['value']['X']['value'][:]
          # getting the last 10 frames of the next clip (ignoring the first 8 frames of the previous one and the other ones from itself)
          for j in range(99,109):
             data[0,j-99,0,0:32,0:32] = frames[j,0:32,0:32]

       # cleaning the last frame from the data 10+1 (to remove any possible noise)
       data[0,10,0,0:32,0:32] = 0


       # removing previous saved file
       if os.path.exists(os.path.join(self.DATA_DIR, self.version + '_test.npy')):
          os.system('rm ' +os.path.join(self.DATA_DIR, self.version + '_test.npy'))
       # saving the new data
       np.save(os.path.join(self.DATA_DIR, self.version + '_test.npy'), data)
    #------------------




    #-------------
    # predict frames
    def predict(self, data_path,OUTPUT_DATA,clip_id):

       # Load trained model
       vprint(self.verbose, "Loading trained prednet model")
       f = open(self.json_file, 'r')
       json_string = f.read()
       f.close()
       self.train_model = model_from_json(json_string, custom_objects = {'PredNet': PredNet})
       self.train_model.load_weights(self.weights_file)

       # adapted from Marc's code
       nt = self.S_HELD + self.S_PRED

       # Create testing model (to output predictions)
       vprint(self.verbose, "Creating test prednet model")
       layer_config = self.train_model.layers[1].get_config()
       layer_config['output_mode'] = 'prediction'
       self.dim_ordering = layer_config['dim_ordering']
       test_prednet = PredNet(weights=self.train_model.layers[1].get_weights(), **layer_config)
       input_shape = list(self.train_model.layers[0].batch_input_shape[1:])
       input_shape[0] = nt
       inputs = Input(shape=tuple(input_shape))
       predictions = test_prednet(inputs)
       self.test_model = Model(input=inputs, output=predictions)


       # creating the idx to shift the data (0, 1, 2, 3; 1, 2, 3; 1, 2, 3; ...; 1, 2, 3)
       if clip_id<4:
          id_aux = clip_id
       else:
          if clip_id%3==0:
             id_aux = 3
          else:
             id_aux = clip_id%3

       # from the h5py file, generate the npy file in the NEW_DATA_DIR_AUX directory
       self.generate_test_file(data_path,clip_id,id_aux)
       test_file = os.path.join(self.DATA_DIR,self.version + '_test.npy')

       # create a variable to record the 8 predicted clips
       predicted = np.zeros((8,32,32))

       # now, given 10 clips, predict the next 1.
       for frame in range(0,8):

          # Prepare ground truth and predictions
          X_test = SequenceGeneratorChalearn(test_file, nt, unique_start='unique', dim_ordering=self.dim_ordering).create_all()
          X_hat = np.copy(X_test)

          for i in range(self.S_HELD, self.S_HELD+self.S_PRED):
             X_hat[:, i] = self.test_model.predict(X_hat, self.test_batch_size)[:, i]

          # here shif the data and save (using the predicted frame as input of the next prediction)
          for i in range(0,10):
             X_hat[0,i,0,0:32,0:32] = X_hat[0,i+1,0:32,0:32]

          # save the data (not optimized solution)
          np.save(os.path.join(self.DATA_DIR,self.version + '_test.npy'), X_hat)

       # Reorder gt and predictions dimensions if using theano dimension ordering
       if self.dim_ordering == 'th':
          X_hat = np.transpose(X_hat, (0, 1, 3, 4, 2))

       # save only predicted ones (last 8 frames) and not the whole clip (109) (1, 109, 32, 32, 1) -> (1, 8, 32, 32, 1)
       for i in range(0,8):
          predicted[i,0:32,0:32] = X_hat[0,3+i,0:32,0:32,0]

       Dout = DataManager(datatype="output", verbose=True)
       Dout.X = predicted
       Dout.saveData('Y' + str(clip_id), data_dir=OUTPUT_DATA, format="h5")
    #------------------




    #-------------------------
    # train the model
    def fit(self, data_path, save_model = True):
       '''
       Train PredNet on See4C sequences. 
       '''
       # Prepare data
       self.generate_train_data(data_path)
    
       # Data files
       train_file = os.path.join(self.DATA_DIR, self.version + '_train.npy')
       val_file = os.path.join(self.DATA_DIR, self.version + '_valid.npy')

       # Parameters      
       N_seq_val = int(np.load(os.path.join(self.DATA_DIR, 'num_seq_valid.npy')))

       # Model parameters
       stack_sizes = (self.input_shape[0], self.stack_size[0], self.stack_size[1],self.stack_size[2])
       R_stack_sizes = stack_sizes
       layer_loss_weights = np.array(self.layer_loss_weights)
       layer_loss_weights = np.expand_dims(self.layer_loss_weights, 1)
       time_loss_weights = 1./ (self.nt - 1) * np.ones((self.nt,1))
       time_loss_weights[0] = 0
    
       prednet = PredNet(stack_sizes, R_stack_sizes,
                      self.A_filt_sizes, self.Ahat_filt_sizes, self.R_filt_sizes,
                      output_mode='error', return_sequences=True)
    
       inputs = Input(shape=(self.nt,) + self.input_shape)
       errors = prednet(inputs)  # errors will be (self.train_batch_size, self.nt, nb_layers)
       errors_by_time = TimeDistributed(Dense(1, weights=[layer_loss_weights, np.zeros(1)], trainable=False), trainable=False)(errors)  # calculate weighted error by layer
       errors_by_time = Flatten()(errors_by_time)  # will be (self.train_batch_size, self.nt)
       final_errors = Dense(1, weights=[time_loss_weights, np.zeros(1)], trainable=False)(errors_by_time)  # weight errors by time
       model = Model(input=inputs, output=final_errors)
       model.compile(loss=self.loss, optimizer=self.optimizer)
    
       train_generator = SequenceGeneratorChalearn(train_file, self.nt, batch_size=self.train_batch_size, shuffle=True)
       val_generator = SequenceGeneratorChalearn(val_file, self.nt, batch_size=self.train_batch_size, N_seq=N_seq_val)

       lr_schedule = lambda epoch: self.start_lr if epoch < 75 else self.end_lr    # start with lr large and then drop to smaller value after 75 epochs
       callbacks = [LearningRateScheduler(lr_schedule)]
       if save_model:
           if not os.path.exists(self.WEIGHTS_DIR): os.mkdir(self.WEIGHTS_DIR)
           callbacks.append(ModelCheckpoint(filepath=self.weights_file, monitor='val_loss', save_best_only=True))
  
       self.history = model.fit_generator(train_generator, self.samples_per_epoch, self.nb_epoch, callbacks=callbacks,
                       validation_data=val_generator, nb_val_samples=N_seq_val)
    
       if save_model:
           json_string = model.to_json()
           with open(self.json_file, "w") as f:
               f.write(json_string)
    #---------------------


